<?php

require 'function.php';

?>
<table border="1">
<tr>
<th>No</th>
<th>Npm</th>
<th>Nama Mahasiswa</th>
<th>Alamat</th>
<th>Program Studi</th>
<th>Tanggal Lahir</th>
<th>Jenis kelamin</th>
<th>Username</th>
<th>Password</th>
</tr>


<?php
$no=1;
$sql= mysqli_query($conn, "select * from users ");
while($data=mysqli_fetch_array($sql)){

?>

<tr>
<td><?php echo $no++; ?></td>
<td><?php echo $data['npm']; ?></td>
<td><?php echo $data['nama_mahasiswa']; ?></td>
<td><?php echo $data['alamat']; ?></td>
<td><?php echo $data['jurusan']; ?></td>
<td><?php echo $data['tanggal_lahir']; ?></td>
<td><?php echo $data['jenis_kelamin']; ?></td>
<td><?php echo $data['username']; ?></td>
<td><?php echo $data['password']; ?></td>
</tr>
<?php
}
?>
</table>
<body>
    <div>
<span><a href="cetakexcel.php" class="btn btn-info">Cetak Excel</a></span>
<br>
<span><a href="cetakpdf.php" class="btn btn-info">Cetak pdf</a></span>
</div>

</body>
