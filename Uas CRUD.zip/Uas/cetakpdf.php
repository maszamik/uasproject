<?php
include('function.php');
require_once("dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();
$query = mysqli_query($conn, "select * from users");

$html = '<hr><center><h3>Data Mahasiswa</h3></center><hr/><br/>';
$html .= '<table border="1" width="100%">
<tr>
<th>NO.</th>
<th>NPM</th>
<th>Nama Mahasiswa</th>
<th>Alamat</th>
<th>Program Studi</th>
<th>Tanggal Lahir</th>
<th>Jenis Kelamin</th>
<th>Username</th>
<th>Password</th>
</tr>';
$no = 1;
while ($row = mysqli_fetch_array($query)) {
    $html .= "<tr>
    <td>" . $no . "</td>
    <td>" . $row['npm'] . "</td>
    <td>" . $row['nama_mahasiswa'] . "</td>
    <td>" . $row['alamat'] . "</td>
    <td>" . $row['jurusan'] . "</td>
    <td>" . $row['tanggal_lahir'] . "</td>
    <td>" . $row['jenis_kelamin'] . "</td>
    <td>" . $row['username'] . "</td>
    <td>" . $row['password'] . "</td>
    </tr>";
    $no++;
}
$html .= "</html>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A3', 'landscape');
// Rendering dari HTML ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream('data_mahasiswa.pdf');
