<?php
include('function.php');

// menggunakan library phpspreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// var mengisi kotak-kotak
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'No');
$sheet->setCellValue('B1', 'NPM');
$sheet->setCellValue('C1', 'Nama Mahasiswa');
$sheet->setCellValue('D1', 'Alamat');
$sheet->setCellValue('E1', 'Program Studi');
$sheet->setCellValue('F1', 'Tanggal Lahir');
$sheet->setCellValue('G1', 'Jenis Kelamin');
$sheet->setCellValue('H1', 'Username');
$sheet->setCellValue('I1', 'Password');

// menggisi kotak-kotak dengan singkat
$query = mysqli_query($conn, "select * from users");
$i = 2;
$no = 1;
while ($row = mysqli_fetch_array($query)) {
    $sheet->setCellValue('A' . $i, $no++);
    $sheet->setCellValue('B' . $i, $row['npm']);
    $sheet->setCellValue('C' . $i, $row['nama_mahasiswa']);
    $sheet->setCellValue('D' . $i, $row['alamat']);
    $sheet->setCellValue('E' . $i, $row['jurusan']);
    $sheet->setCellValue('F' . $i, $row['tanggal_lahir']);
    $sheet->setCellValue('G' . $i, $row['jenis_kelamin']);
    $sheet->setCellValue('H' . $i, $row['username']);
    $sheet->setCellValue('I' . $i, $row['password']);
    $i++;
}
// var array batasan kotak
$styleArray = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
        ],
    ],
];
$i = $i - 1;
$sheet->getStyle('A1:D' . $i)->applyFromArray($styleArray);

// var menyimpan dengan format xlsx
$writer = new Xlsx($spreadsheet);
$writer->save('Report Data Mhasiwa.Xlsx');
