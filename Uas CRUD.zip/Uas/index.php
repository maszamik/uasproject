<?php

session_start();

if (isset($_SESSION['login'])) {
    $username = $_SESSION['username'];
    }else{
    header("Location: login.php");
    exit;
}

require 'function.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
</head>
<style>
    body {
            background: #ffd700;
        }
</style>
<center>
<body>
	<div id="profile">
		<b id="welcome"><?php echo $username; ?> Berhasil Login Pada <?php echo date("l, m-d-Y"); ?></b>
<br>
<br>
<div>
<span><a href="logout.php" class="btn btn-danger">Keluar</a></span>
</div>
</center>
</body>
</html>